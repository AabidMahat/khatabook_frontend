import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


import 'package:khatabook_project/CreateAccount.dart';
import 'package:khatabook_project/Register.dart';
import 'package:http/http.dart' as http;
import 'package:khatabook_project/admin.dart';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:toastification/toastification.dart';
import 'Dashboard.dart';

void main() {
  runApp(MaterialApp(
    home: MyLogin(),
  ));
}

class MyLogin extends StatefulWidget {
  const MyLogin({super.key});

  @override
  State<MyLogin> createState() => _MyLoginState();
}

class _MyLoginState extends State<MyLogin> {
  var emailText = TextEditingController();
  var passText = TextEditingController();
  bool _isPasswordVisible = false;
  var userId;

  void loginAccount() async {
    try {
      final String url = "https://aabid.up.railway.app/api/v3/user/login";

      var loginBody = {"email": emailText.text, "password": passText.text};

      var response = await http.post(Uri.parse(url),
          body: json.encode(loginBody),
          headers: {"Content-Type": "application/json"});

      if (response.statusCode == 200) {
        var data = json.decode(response.body);
        userId = data['data']['_id'];

        print("Login $userId");

        // Save userId to shared preferences
        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.setString('userId', userId);
        toastification.show(
          context: context,
          type: ToastificationType.success,
          autoCloseDuration: Duration(milliseconds: 3000),
          title: Text("User logged in sucessfully"),
        );
        Future.delayed(Duration(milliseconds: 2000), () {
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (context) => data['data']['account_id'].isEmpty
                      ? AddAccount()
                      : Dashboard(),
                  settings: RouteSettings(arguments: {"userId": userId})));
        });
      } else {
        var errorMessage =
            json.decode(response.body)['message'] ?? 'LogIn failed';
        toastification.show(
          context: context,
          type: ToastificationType.error,
          title: Text(errorMessage),
          icon: Icon(Icons.error),
          autoCloseDuration: Duration(milliseconds: 3000),
        );
      }
    } catch (err) {
      print(err);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage(
                "android/assets/loginPage.png",
              ),
              fit: BoxFit.cover)),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Stack(
          children: [
            Container(
              padding: EdgeInsets.only(left: 35, top: 130),
              child: Text(
                "Welcome\nBack",
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 33,
                    fontWeight: FontWeight.bold),
              ),
            ),
            SingleChildScrollView(
              child: Container(
                padding: EdgeInsets.only(
                    top: MediaQuery.of(context).size.height * 0.5,
                    right: 35,
                    left: 35),
                child: Column(
                  children: [
                    TextField(
                      controller: emailText,
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: Colors.grey.shade100,
                        // Use white color for the text field background
                        labelText: "Email",
                        labelStyle: TextStyle(color: Colors.grey.shade600),
                        // Adjust label text color
                        enabledBorder: UnderlineInputBorder(
                          // Underline border
                          borderSide: BorderSide(
                              color: Colors.grey.shade400), // Border color
                        ),
                        focusedBorder: UnderlineInputBorder(
                          // Focused underline border
                          borderSide: BorderSide(
                              color: Colors.blue), // Border color on focus
                        ),
                        prefixIcon: Icon(Icons.email),
                        // Add an icon prefix
                        suffixIcon: IconButton(
                          onPressed: () {
                            emailText.clear();
                          },
                          icon: Icon(Icons.clear), // Use a standard clear icon
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                    TextField(
                      controller: passText,
                      obscureText: !_isPasswordVisible,
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: Colors.grey.shade100,
                        // Use white color for the text field background
                        labelText: "Password",
                        labelStyle: TextStyle(color: Colors.grey.shade600),
                        // Adjust label text color
                        enabledBorder: UnderlineInputBorder(
                          // Underline border
                          borderSide: BorderSide(
                              color: Colors.grey.shade400), // Border color
                        ),
                        focusedBorder: UnderlineInputBorder(
                          // Focused underline border
                          borderSide: BorderSide(
                              color: Colors.blue), // Border color on focus
                        ),
                        prefixIcon: Icon(Icons.lock),
                        // Add an icon prefix
                        suffixIcon: IconButton(
                          icon: Icon(_isPasswordVisible
                              ? Icons.visibility
                              : Icons.visibility_off),
                          onPressed: () {
                            setState(() {
                              _isPasswordVisible = !_isPasswordVisible;
                            });
                          },
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 40,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Sign in",
                          style: TextStyle(
                              color: Color(0xff4c505b),
                              fontSize: 27,
                              fontWeight: FontWeight.w700),
                        ),
                        CircleAvatar(
                          radius: 30,
                          backgroundColor: Color(0xff4c505b),
                          child: IconButton(
                            onPressed: () {
                              loginAccount();
                            },
                            icon: Icon(
                              Icons.arrow_forward,
                              color: Colors.white,
                            ),
                          ),
                        )
                      ],
                    ),
                    SizedBox(
                      height: 40,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        TextButton(
                            onPressed: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => Register(),
                                  ));
                            },
                            child: Text(
                              "Sign Up",
                              style: TextStyle(
                                  decoration: TextDecoration.underline,
                                  fontSize: 18,
                                  color: Color(0xff4c505b)),
                            )
                        ),
                        TextButton(
                            onPressed: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => Admin(),
                                  ));
                            },
                            child: Text(
                              "Admin Login",
                              style: TextStyle(
                                  decoration: TextDecoration.underline,
                                  fontSize: 18,
                                  color: Color(0xff4c505b)),
                            )
                        ),
                      ],
                    )
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
