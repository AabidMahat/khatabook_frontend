import 'dart:math';

import 'package:contacts_service/contacts_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:permission_handler/permission_handler.dart';

class PhoneBook extends StatefulWidget {
  const PhoneBook({super.key});

  @override
  State<PhoneBook> createState() => _PhoneBookState();
}

class _PhoneBookState extends State<PhoneBook> {
  List<Contact> contacts = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    getContactPermission();
  }

  void getContactPermission() async {
    if (await Permission.contacts.isGranted) {
      fetchContacts();
    } else {
      var status = await Permission.contacts.request();
      if (status.isGranted) {
        fetchContacts();
      }
    }
  }

  String formatPhoneNumber(String phone) {
    // Remove any country code prefix
    if (phone.startsWith('+91')) {
      phone = phone.substring(3).trim();
    }
    // Remove any spaces or dashes
    phone = phone.replaceAll(RegExp(r'\s+|-'), '');
    return phone;
  }

  void fetchContacts() async {
    contacts = await ContactsService.getContacts();
    setState(() {
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade900,
      appBar: AppBar(
        backgroundColor: Colors.grey.shade900,
        title: const Text(
          "Contacts",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      body: isLoading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : ListView.builder(
              itemCount: contacts.length,
              itemBuilder: (context, index) {
                var contact = contacts[index];
                var initial = contact.givenName?.isNotEmpty == true
                    ? contact.givenName![0]
                    : '';
                var name = contact.givenName ?? 'No name';
                var phone = contact.phones?.isNotEmpty == true
                    ? formatPhoneNumber(contact.phones![0].value ?? 'No phone')
                    : 'No phone';

                return ListTile(
                  leading: Container(
                    height: 30.h,
                    width: 30.h,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          blurRadius: 7,
                          color: Colors.white.withOpacity(0.1),
                          offset: const Offset(-3, -3),
                        ),
                        BoxShadow(
                          blurRadius: 7,
                          color: Colors.black.withOpacity(0.7),
                          offset: const Offset(3, 3),
                        ),
                      ],
                      borderRadius: BorderRadius.circular(6.r),
                      color: const Color(0xff262626),
                    ),
                    child: Text(
                      initial,
                      style: TextStyle(
                        fontSize: 23.sp,
                        color: Colors.primaries[
                            Random().nextInt(Colors.primaries.length)],
                        fontFamily: "Poppins",
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  title: Text(
                    name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 16.sp,
                      color: Colors.cyanAccent,
                      fontFamily: "Poppins",
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  subtitle: Text(
                    phone,
                    style: TextStyle(
                      fontSize: 11.sp,
                      color: const Color(0xffC4c4c4),
                      fontFamily: "Poppins",
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  horizontalTitleGap: 12.w,
                  onTap: () {
                    Navigator.pop(context, phone);
                  },
                );
              },
            ),
    );
  }
}
