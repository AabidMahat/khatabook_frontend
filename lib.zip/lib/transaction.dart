import 'dart:convert';
import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:khatabook_project/AmmountGave.dart';
import 'package:khatabook_project/AmmountGot.dart';
import 'package:khatabook_project/Dashboard.dart';
import 'package:khatabook_project/Database.dart';
import 'package:khatabook_project/UpdateData.dart';
import 'package:khatabook_project/newUpdateData.dart';
import 'package:khatabook_project/sideBar.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:toastification/toastification.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;
import 'card.dart';

void main() {
  AwesomeNotifications().initialize(
    'resource://drawable/res_app_icon',
    [
      NotificationChannel(
        channelKey: 'aabid',
        channelName: 'Basic Notification',
        channelDescription: 'Notification channel for basic test',
      ),
    ],
    debug: true,
  );
}

class Transaction extends StatefulWidget {
  final String studentId;
  final String accountId;

  const Transaction(
      {super.key, required this.studentId, required this.accountId});

  @override
  State<Transaction> createState() => _TransactionState();
}

class _TransactionState extends State<Transaction> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  List<TransactionData> transaction = [];
  Student? student;
  bool isLoading = true;
  String? staffAccess;
  var accountData ;


  @override
  void initState() {
    AwesomeNotifications().isNotificationAllowed().then((isAllowed) {
      if (!isAllowed) {
        AwesomeNotifications().requestPermissionToSendNotifications();
      }
    });
    super.initState();
    getStaffAccess();
    getTransaction();
    getStudentAccunt();
    fetchAccountDetails();
  }

  DateTime? _dateController;

  void getStaffAccess() async {
    SharedPreferences pref = await SharedPreferences.getInstance();

    setState(() {
      staffAccess = pref.getString('setAccess');
    });
    print("Transaction $staffAccess");
  }

  void getTransaction() async {
    try {
      var response = await http.get(Uri.parse(
          "https://aabid.up.railway.app/api/v3/transaction/seeTransaction/studentId=${widget.studentId}"));
      if (response.statusCode == 202) {
        var data = jsonDecode(response.body);
        setState(() {
          transaction = List<TransactionData>.from(
            data['data'].map((values) => TransactionData.fromJson(values)),
          );

          isLoading = false; // Set loading to false when data is loaded
        });
        getStudentAccunt();
      } else {
        print("Failed to load transactions: ${response.statusCode}");
        setState(() {
          isLoading = false;
        });
      }
    } catch (err) {
      setState(() {
        isLoading = false;
      });
      print("No data: $err");
    }
  }
  Future<void> fetchAccountDetails() async {
    final url =
        'https://aabid.up.railway.app/api/v3/account/getAccount/account_id=${widget.accountId}';
    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final responseBody = jsonDecode(response.body);
        accountData = responseBody['data']['account'];

      } else {
       // Debug statement
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Failed to load account details')));
      }
    } catch (e) {
      print('Error: $e'); // Debug statement
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Error: ${e.toString()}')));
    }
  }

  void getStudentAccunt() async {
    final String url =
        "https://aabid.up.railway.app/api/v3/student/fetchStudent/studentId=${widget.studentId}";
    try {
      var response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);

        setState(() {
          student = Student.fromJson(data['data'][0]);
          isLoading = false;
        });
      } else {
        print("Failed to load Student: ${response.statusCode}");
        setState(() {
          isLoading = false;
        });
      }
    } catch (err) {
      setState(() {
        isLoading = false;
      });
      print("No data : $err");
    }
  }

  void triggerNotification() {
    AwesomeNotifications().createNotification(
        content: NotificationContent(
            id: 10,
            channelKey: 'aabid',
            title: 'Reminder Set',
            body:
                'Reminder has been set for ${_dateController!.day}/${_dateController!.month}/${_dateController!.year}',
            notificationLayout: NotificationLayout.Default));
  }

  void scheduleNotification(DateTime scheduledDate) {
    AwesomeNotifications().createNotification(
      content: NotificationContent(
        id: 20,
        channelKey: 'aabid',
        title: 'Reminder',
        body: 'This is your reminder for today',
        notificationLayout: NotificationLayout.Default,
      ),
      schedule: NotificationCalendar(
        year: scheduledDate.year,
        month: scheduledDate.month,
        day: scheduledDate.day,
        hour: 9,
        // Set the desired time for the reminder
        minute: 0,
        second: 0,
        millisecond: 0,
        repeats: false,
      ),
    );
  }

  Future<void> _selectDate() async {
    DateTime? _picked = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(2024),
        lastDate: DateTime(2027));

    if (_picked != null) {
      setState(() {
        _dateController = _picked;
      });
      triggerNotification();
      scheduleNotification(_picked);
    }
  }

  Future<void> sendWhatsApp() async {
    var phone = student?.phone;
    var text =
        "${accountData['whatsapp_template']}\n Pending fees : ₹${(student!.totalFees - student!.paidFees)}";
    var url = "https://wa.me/$phone?text=$text";
    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url));
    } else {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text("Could not launch $url")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
              builder: (context) => Dashboard(),
              settings: RouteSettings(arguments: {
                "staffAccess": staffAccess,
              })),
        );
        return false;
      },
      child: Scaffold(
        key: _scaffoldKey,
        appBar: _buildAppBar(),
        drawer: SideBarWidget(accountId: widget.accountId),
        body: Column(
          children: [
            // _buildReminderCard(),
            _buildRemainderNewCard(),
            _buildURLContainer(),
            _buildEntriesHeader(),
            SizedBox(
              height: 10,
            ),
            _buildEntriesList(),
          ],
        ),
        bottomNavigationBar: (staffAccess == "medium" ||
                staffAccess == "high" ||
                staffAccess == "")
            ? _buildBottomNavigationBar()
            : null,
      ),
    );
  }

  AppBar _buildAppBar() {
    return AppBar(
      backgroundColor: Color(0xFF3F704D),
      actions: [
        IconButton(
          onPressed: () {

            Navigator.push(context, MaterialPageRoute(builder: (context)=>UpdateSetting(),settings: RouteSettings(
              arguments: {
                "studentId": widget.studentId,
                "student": student,
              }
            )));
          },
          icon: Icon(
            Icons.edit,
            color: Colors.white,
            size: 24,
          ),
        ),
      ],
      leading: IconButton(
        onPressed: () {
          _scaffoldKey.currentState?.openDrawer();
        },
        icon: Icon(
          Icons.menu,
          color: Colors.white,
        ),
      ),
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          CircleAvatar(
            backgroundColor: Colors.white,
            backgroundImage: NetworkImage("${student?.imagePath}"),
          ),
          SizedBox(width: 10),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                AnimatedSwitcher(
                  duration: Duration(milliseconds: 500),
                  child: student?.studentName != null
                      ? Text(
                    student!.studentName,
                    key: ValueKey('studentName'),
                    style: TextStyle(color: Colors.white),
                    overflow: TextOverflow.ellipsis,
                  )
                      : Text(
                    'Loading...',
                    key: ValueKey('loading'),
                    style: TextStyle(color: Colors.white),
                  )
                      .animate(
                      onComplete: (controller) => controller.repeat())
                      .fadeIn(duration: 500.ms)
                      .fadeOut(duration: 500.ms),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }


  Widget _buildRemainderNewCard() {
    return Padding(
      padding: EdgeInsetsDirectional.fromSTEB(0, 0, 0, 12),
      child: Material(
        color: Colors.transparent,
        elevation: 10,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(0),
        ),
        child: Container(
          width: MediaQuery.sizeOf(context).width,
          decoration: BoxDecoration(
            color: Color(0xFF3F704D),
            // borderRadius: BorderRadius.only(
            //     bottomLeft: Radius.circular(24),
            //     bottomRight: Radius.circular(24)),
            boxShadow: [
              BoxShadow(
                blurRadius: 5,
                color: Color(0x32171717),
                offset: Offset(0, 2),
              )
            ],
            border: Border.all(
              color: Color(0xFF3F704D),
            ),
          ),
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(20, 8, 20, 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      "₹ ${student != null ? (student!.totalFees) : 0}",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: 'Outfit',
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Text(
                      'Total Amount',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: 'Plus Jakarta Sans',
                        color: Color(0xB3FFFFFF),
                        fontSize: 12,
                        fontWeight: FontWeight.w300,
                      ),
                    ),
                  ],
                ),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      "₹ ${student != null ? (student!.totalFees - student!.paidFees) : 0}",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: 'Outfit',
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Text(
                      'Pending Amount',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: 'Plus Jakarta Sans',
                        color: Color(0xB3FFFFFF),
                        fontSize: 12,
                        fontWeight: FontWeight.w300,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildURLContainer() {
    return Container(
      height: 70,
      child: Align(
        alignment: AlignmentDirectional(0, 0),
        child: Row(
          mainAxisSize: MainAxisSize.max,
          children: [
            SizedBox(
              width: 10,
            ),
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    blurRadius: 3,
                    color: Color(0x35000000),
                    offset: Offset(
                      0.0,
                      1,
                    ),
                  )
                ],
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: Color(0xFFF1F4F8),
                  width: 1,
                ),
              ),
              child: Row(
                children: [
                  IconButton(
                    style: IconButton.styleFrom(
                      backgroundColor: Colors.transparent,
                    ),
                    icon: Icon(
                      Icons.calendar_month,
                      color: Color(0xFF3F704D),
                      size: 36,
                    ),
                    onPressed: _selectDate,
                  ),
                  SizedBox(width: 7), // Add space between icon and text
                  Text(
                    _dateController == null
                        ? "Set Date"
                        : "${_dateController!.day}/${_dateController!.month}/${_dateController!.year}",
                    textAlign: TextAlign.start,
                    style: TextStyle(
                      fontFamily: 'Readex Pro',
                      fontSize: 16,
                      letterSpacing: 0,
                      fontWeight: FontWeight.normal,
                    ),
                  ),
                  SizedBox(width: 16), // Add space between icon and text
                ],
              ),
            ),
            SizedBox(width: 18), // Add space between icon and text

            Align(
              alignment: AlignmentDirectional(0, 0),
              child: IconButton(
                style: IconButton.styleFrom(
                  backgroundColor: Colors.transparent,
                ),
                icon: FaIcon(
                  FontAwesomeIcons.whatsapp,
                  color: Color(0xFF3F704D),
                  size: 36,
                ),
                onPressed: () {
                  print("Whatsapp ${accountData['whatsapp_template']}");
                  if (accountData['whatsapp_template'] != "" && accountData['whatsapp_template'] != null) {
                    sendWhatsApp();
                  } else {
                    toastification.show(
                      context: context,
                      title: Text("Please select the template"),
                      autoCloseDuration: Duration(seconds: 3),
                    );
                  }
                },
              ),
            ),
            SizedBox(width: 16), // Add space between icon and text

            Align(
              alignment: AlignmentDirectional(0, 0),
              child: IconButton(
                style: IconButton.styleFrom(
                  backgroundColor: Colors.transparent,
                ),
                icon: Icon(
                  Icons.message,
                  color: Color(0xFF3F704D),
                  size: 36,
                ),
                onPressed: () {
                  if (accountData['sms_template'] != "" && accountData['sms_template'] != null) {
                    launch(
                        'sms:${student!.phone}?body=${accountData['sms_template']}.\nPending fees:₹${(student!.totalFees - student!.paidFees)}');
                  } else {
                    toastification.show(
                      context: context,
                      title: Text("Please select the template"),
                      autoCloseDuration: Duration(seconds: 3),
                    );
                  }
                },
              ),
            ),
            SizedBox(width: 16), // Add space between icon and text

            Align(
              alignment: AlignmentDirectional(0, 0),
              child: IconButton(
                style: IconButton.styleFrom(
                  backgroundColor: Colors.transparent,
                ),
                icon: Icon(
                  Icons.phone_in_talk,
                  color: Color(0xFF3F704D),
                  size: 36,
                ),
                onPressed: () {
                  launchUrl(Uri.parse("tel:${student!.phone}"));
                },
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildEntriesHeader() {
    return Container(
      padding: EdgeInsets.all(5),
      child: Text(
        'Transactions',
        textAlign: TextAlign.start,
        style: TextStyle(
          fontFamily: 'Readex Pro',
          fontSize: 16,
          letterSpacing: 0,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget _buildEntriesList() {
    if (isLoading) {
      return Center(
        child: CircularProgressIndicator(),
      );
    } else if (transaction.isEmpty) {
      return Center(child: Text('No transactions found'));
    } else {
      return Expanded(
        child: ListView.builder(
          itemCount: transaction.length,
          itemBuilder: (context, index) {
            return CardWidget(
              transaction: transaction[index],
              onDelete: () {
                getTransaction();
                getStudentAccunt();
              },
              onUpdate: () {
                getTransaction();
                getStudentAccunt();
              },
              student: student!,
            ).animate().fadeIn(duration: Duration(milliseconds: 1000));
          },
        ),
      );
    }
  }

  Widget _buildBottomNavigationBar() {
    return Container(
      height: 60,
      margin: EdgeInsets.all(10),
      child: Row(
        children: [
          Expanded(
            child: TextButton(
              onPressed: () {
                var student_id = widget.studentId;
                var account_id = widget.accountId;
                var pendingAmount = transaction.isNotEmpty
                    ? transaction[transaction.length - 1].pendingAmount
                    : 0;
                Navigator.push(context, MaterialPageRoute(builder: (context)=>AmmountGivePage(),settings: RouteSettings(
                  arguments: {
                    'student_id': student_id,
                    'account_id': account_id,
                    "pendingAmount": pendingAmount,
                    "student": student,
                  }
                )));
              },
              style: TextButton.styleFrom(
                backgroundColor: Colors.red,
                primary: Colors.white,
              ),
              child: Text('Request Pay ₹', style: TextStyle(fontSize: 16)),
            ),
          ),
          SizedBox(width: 20),
          Expanded(
            child: TextButton(
              onPressed: () {
                var student_id = widget.studentId;
                var account_id = widget.accountId;
                var pendingAmount =
                    transaction[transaction.length - 1].pendingAmount;
                Navigator.push(context, MaterialPageRoute(builder: (context)=>AmmountGotPage(),settings: RouteSettings(
                  arguments: {
                    'student_id': student_id,
                    'account_id': account_id,
                    "pendingAmount": pendingAmount,
                    "student": student,
                  }
                )));
              },
              style: TextButton.styleFrom(
                backgroundColor: Colors.green,
                primary: Colors.white,
              ),
              child: Text('Collect Pay ₹', style: TextStyle(fontSize: 16)),
            ),
          ),
        ],
      ),
    );
  }
}
