import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'allAccounts.dart';

void main(){
  runApp(
      MaterialApp(
        home: Admin(),
        ));
}
class Admin extends StatefulWidget {
  const Admin({super.key});

  @override
  State<Admin> createState() => _AdminState();
}

class _AdminState extends State<Admin> {
  var usernameText = TextEditingController();
  var passText = TextEditingController();
  bool _isPasswordVisible = false;
  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage("android/assets/background.jpeg",),
                fit: BoxFit.cover
            )
        ),

      child:Scaffold(
        backgroundColor: Colors.transparent,
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: MediaQuery.of(context).size.height*0.5,
              width: MediaQuery.of(context).size.width,
              child: Image.asset("android/assets/admin.png",fit: BoxFit.cover,),
            ),
            Container(
              padding: EdgeInsets.only(right: 30,left: 30),

                child: Column(
                  children: [
                    TextField(
                      controller: usernameText,
                      decoration: InputDecoration(

                        hintText: "Username",
                        labelText: "Username",
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)
                        ),
                          suffixIcon: IconButton(onPressed: () {
                            usernameText.clear();
                          }, icon: Icon(CupertinoIcons.clear_thick_circled,color: Colors.blue[900],),)
                      ),
                    ),
                    SizedBox(height: 30,),
                    TextField(
                      controller: passText,
                      obscureText: !_isPasswordVisible,
                      decoration: InputDecoration(
                          hintText: "Password",
                          labelText: "Password",
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10)
                          ),
                          suffixIcon: IconButton(
                      icon: Icon(_isPasswordVisible ? Icons.visibility : Icons.visibility_off,color: Colors.blue[900],),
                      onPressed: () {
                        setState(() {
                          _isPasswordVisible = !_isPasswordVisible;
                        });
                      },
                    ),
                      ),

                    ),
                    SizedBox(height: 60,),
                    Container(
                      height: 50,
                      width: 200,
                      child: ElevatedButton(

                          style: ElevatedButton.styleFrom(

                            backgroundColor: Colors.blue[900],
                            elevation: 0.3,
                            shadowColor: Colors.grey
                          ),
                          onPressed: (){
                            String username=usernameText.text.toString();
                            String password=passText.text.toString();
                            if(username=="admin" && password=="admin@1234"){
                              Navigator.push(context, MaterialPageRoute(builder: (context) => Accounts(),));
                            }else {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('Wrong username or password')),
                              );

                            }
                            }, child: Text("Login",style: TextStyle(
                        color: Colors.white,
                        fontSize: 20
                      ),)),
                    )
                  ],
                ),
              ),

          ],
        ),
      ),
    ));
  }
}
