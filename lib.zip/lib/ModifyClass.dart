import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:khatabook_project/AllTeachers.dart';
import 'package:khatabook_project/Dashboard.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:toastification/toastification.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(MaterialApp(
    home: ModifyClass(),
  ));
}

class ModifyClass extends StatefulWidget {
  const ModifyClass({super.key});

  @override
  State<ModifyClass> createState() => _ModifyClassState();
}

class _ModifyClassState extends State<ModifyClass> {
  var organisationName = TextEditingController();
  var staffName = TextEditingController();
  String? organisationType;
  final _formKey = GlobalKey<FormState>();
  String? account_name;
  String? accountId;
  bool isActive = true;
  late String userId;
  late Map<String, dynamic> args;
  late String classId;
  late String className;
  bool isLoading = false;
  String? staffAccess;
  String ? staffId;
  var staff;
  var allStaffs;

  @override
  void initState() {
    super.initState();
    getUserIdFromSharedPreferences();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final arguments = ModalRoute.of(context)?.settings.arguments;
      if (arguments != null) {
        args = arguments as Map<String, dynamic>;
        classId = args['classId'];
        className = args['className'];
        staffId = args['staffId'];
        organisationName.text = className;

        getStaff(staffId!);
      } else {
        // Handle case where arguments are not passed correctly
        print('Arguments not passed correctly');
      }
    });
  }

  void getUserIdFromSharedPreferences() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      userId = prefs.getString('userId') ?? '';
      staffAccess = prefs.getString("setAccess");
      accountId = prefs.getString("selectedAccountId");
    });
    getAllStaff(accountId!);
  }

  void getStaff(String staffId)async{
    final String url = "https://aabid.up.railway.app/api/v3/staff/getStaff/$staffId";

    var response = await http.get(Uri.parse(url));

    if(response.statusCode==200){
      var data = json.decode(response.body);
      setState(() {
        staff = data['data'];
        staffName.text = staff['staff_name'];
      });
    }else{
      print("Failed to load Staff");
    }
  }

  void getAllStaff(String accountId)async{
    final String url = "https://aabid.up.railway.app/api/v3/staff/getAllStaff/$accountId";

    var response = await http.get(Uri.parse(url));

    if(response.statusCode==200){
      var data = json.decode(response.body);
      setState(() {
        allStaffs = data['data'];
      });
      print(allStaffs);
    }else{
      print("Failed to load Staff");
    }
  }



  void updateClass(String classId, String newClassName) async {
    final String url =
        "https://aabid.up.railway.app/api/v3/class/updateClass/$classId";
    var updateBody = {
      "class_name": newClassName,
      "teacherId": staffId,
      "teacher_name":staffName.text,
    };

    var response = await http.patch(Uri.parse(url),
        body: json.encode(updateBody),
        headers: {"Content-Type": "application/json"});

    print("Class ${response.body}");
    if (response.statusCode == 200) {
      toastification.show(
          context: context,
          type: ToastificationType.success,
          autoCloseDuration: Duration(milliseconds: 3000),
          title: Text("Data Updated Successfully"));
      Future.delayed(Duration(milliseconds: 1000), () {
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (context) => Dashboard(),
                settings: RouteSettings(arguments: {
                  "staffAccess": staffAccess,
                })));
      });
    } else {
      toastification.show(
          context: context,
          type: ToastificationType.error,
          autoCloseDuration: Duration(milliseconds: 3000),
          title: Text("Failed to Update Data"));
    }
  }

  void deleteClass(String classId) async {
    setState(() {
      isLoading = true;
    });

    final String url =
        "https://aabid.up.railway.app/api/v3/class/deleteClass/$classId";

    var response = await http.delete(Uri.parse(url));
    print(response.body);
    if (response.statusCode == 204) {
      toastification.show(
          context: context,
          type: ToastificationType.success,
          autoCloseDuration: Duration(milliseconds: 1000),
          title: Text("Data Deleted Successfully"));

      Future.delayed(Duration(milliseconds: 1000), () {
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (context) => Dashboard(),
                settings: RouteSettings(arguments: {
                  "staffAccess": staffAccess,
                })));
      });
    } else {
      toastification.show(
          context: context,
          type: ToastificationType.error,
          autoCloseDuration: Duration(milliseconds: 3000),
          title: Text("Failed to Update Data"));
    }

    setState(() {
      isLoading = false;
    });
  }

  void _showSnackBar(String message) {
    final snackBar = SnackBar(content: Text(message));
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Edit Class",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
        ),
        backgroundColor: Colors.green.shade900,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
          onPressed: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => Dashboard()));
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Form(
            key: _formKey, // Make sure form key is linked
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(5),
                  child: TextFormField(
                    controller: organisationName,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelStyle: TextStyle(color: Colors.green.shade900),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.grey.shade200,
                          width: 2,
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.green.shade900,
                          width: 2,
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      filled: true,
                      fillColor: Color(0xFFF1F4F8),
                    ),
                    style: TextStyle(
                      color: Color(0xFF101213),
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter an Staff name';
                      }
                      return null;
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(5),
                  child: DropdownButtonFormField<String>(
                    value: staffId,
                    onChanged: (newValue) {
                      setState(() {
                        staffId = newValue;
                        getStaff(staffId!);
                      });
                    },
                    items: allStaffs?.map<DropdownMenuItem<String>>((staff) {
                      return DropdownMenuItem<String>(
                        value: staff['_id'],
                        child: Text(staff['staff_name']),
                      );
                    }).toList(),
                    decoration: InputDecoration(
                      hintText: 'Assigned Staff',
                      labelStyle: TextStyle(color: Colors.green.shade900),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.grey.shade200,
                          width: 2,
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.green.shade900,
                          width: 2,
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      filled: true,
                      fillColor: Color(0xFFF1F4F8),
                    ),
                    style: TextStyle(
                      color: Color(0xFF101213),
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please select a staff';
                      }
                      return null;
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 5),
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    child: ElevatedButton.icon(
                      icon: Icon(Icons.edit),
                      label: Text("Update"),
                      style: ElevatedButton.styleFrom(
                        primary: Colors.green.shade900,
                        onPrimary: Colors.white,
                        textStyle: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        padding:
                            EdgeInsets.symmetric(horizontal: 60, vertical: 12),
                      ),
                      onPressed: () {
                        if (_formKey.currentState!.validate()) {
                          _formKey.currentState!.save();
                          updateClass(classId, organisationName.text);
                        }
                      },
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    child: ElevatedButton.icon(
                      icon: Icon(Icons.delete),
                      label: Text("Delete"),
                      style: ElevatedButton.styleFrom(
                        primary: Colors.red.shade900,
                        onPrimary: Colors.white,
                        textStyle: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        padding:
                            EdgeInsets.symmetric(horizontal: 60, vertical: 12),
                      ),
                      onPressed: () {
                        deleteClass(classId);
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
