import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:khatabook_project/Dashboard.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:upi_india/upi_india.dart';

void main() {
  runApp(MaterialApp(home: Subscribe()));
}

class Subscribe extends StatefulWidget {
  const Subscribe({super.key});

  @override
  State<Subscribe> createState() => _SubscribeState();
}

class _SubscribeState extends State<Subscribe> {
  Future<UpiResponse>? _transaction;
  final UpiIndia _upiIndia = UpiIndia();
  List<UpiApp>? apps;
  String ? staffAccess;

  @override
  void initState() {
    super.initState();
    getStaffAccess();
    _upiIndia.getAllUpiApps(mandatoryTransactionId: false).then((value) {
      setState(() {
        apps = value;
      });
    }).catchError((e) {
      print(e);
      apps = [];
    });
  }

  void getStaffAccess() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    staffAccess = prefs.getString("setAccess");
  }

  Future<UpiResponse> initiateTransaction(UpiApp app) async {
    return _upiIndia.startTransaction(
      app: app,
      receiverUpiId: "shaikhrafik219@okaxis",
      receiverName: 'Rafik Shaikh',
      transactionRefId: 'TestingUpiIndiaPlugin',
      transactionNote: 'Not actual. Just an example.',
      amount: 99,
    );
  }

  Widget displayUpiApps() {
    if (apps == null) {
      return const Center(child: CircularProgressIndicator());
    } else if (apps!.isEmpty) {
      return const Center(
        child: Text("No apps found to handle transaction"),
      );
    } else {
      return Wrap(
        children: apps!.map<Widget>((UpiApp app) {
          return GestureDetector(
            onTap: () {
              setState(() {
                _transaction = initiateTransaction(app);
              });
            },
            child: Container(
              margin: EdgeInsets.symmetric(vertical: 20,horizontal: 20),
              height: 50,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                color: Colors.green.shade900
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Image.memory(
                    app.icon,
                    height: 30,
                  ),
                  SizedBox(width: 10,),
                  Text(app.name,style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                  ),),
                ],
              ),
            ),
          );
        }).toList(),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
              builder: (context) => Dashboard(),
              settings: RouteSettings(arguments: {
                "staffAccess": staffAccess,
              })),
        );
        return false;
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            "Subscription",
            style: TextStyle(color: Colors.white,fontWeight: FontWeight.w600),
          ),
          backgroundColor: Colors.green.shade900,
          leading: Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
        ),
        body: Center(
          child: Container(
            padding: EdgeInsets.only(top: 10),
            height: 300, // Increased the height to accommodate UPI apps
            width: 300,
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  blurRadius: 3,
                  color: Color(0x35000000),
                  offset: Offset(0, 1),
                ),
              ],
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: Colors.green.shade900,
                width: 1,
              ),
            ),
            child: Column(
              children: [
                Container(
                  padding: EdgeInsets.only(top: 10),
                  child: Align(
                    alignment: AlignmentDirectional(0, -1),
                    child: Text(
                      'Subscribe now',
                      style: TextStyle(
                        fontFamily: 'Readex Pro',
                        fontSize: 24,
                        letterSpacing: 0,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                Container(
                  child: Align(
                    alignment: AlignmentDirectional(0, 0),
                    child: Text(
                      '₹99',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: 'Readex Pro',
                        fontSize: 60,
                        letterSpacing: 0,
                        fontWeight: FontWeight.bold,
                        shadows: [
                          Shadow(
                            color: Colors.grey,
                            offset: Offset(2.0, 2.0),
                            blurRadius: 2.0,
                          )
                        ],
                      ),
                    ),
                  ),
                ),
                Container(
                  child: Align(
                    alignment: AlignmentDirectional(0, -1),
                    child: Text(
                      'Per Year',
                      style: TextStyle(
                        fontFamily: 'Readex Pro',
                        fontSize: 20,
                        letterSpacing: 0,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
                displayUpiApps(), // Display UPI apps
              ],
            ),
          ),
        ),
      ),
    );
  }
}
